#!/bin/bash
echo "Hello!"
echo "You just executed a file."
echo "Permissions control execution in Linux."
